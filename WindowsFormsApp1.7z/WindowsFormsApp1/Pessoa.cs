﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    class Pessoa
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string cidade { get; set; }
        public string endereco { get; set; }
        public string celular { get; set; }
        public string email { get; set; }
        public string data_nascimento { get; set; }

        SqlConnection con =  new SqlConnection/*atribui um método e instancio ele*/(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Aluno\source\repos\WindowsFormsApp1\DbPessoa.mdf;Integrated Security = True");

        public List<Pessoa> listapessoas()/*método público que lista pessoa*/
        {
            List<Pessoa> li = new List<Pessoa>();/*gerei um objeto do tipo lista de nome "li"*/
            string sql = "SELECT * FROM Pessoa";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();/*armazena o comando sql em forma de array*/
            while (dr.Read())
            {
                Pessoa p = new Pessoa();
                p.Id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                cidade = dr["cidade"].ToString();
                endereco = dr["endereco"].ToString();
                celular = dr["celular"].ToString();
                email = dr["email"].ToString();
                data_nascimento = dr["data_nascimento"].ToString();
                li.Add(p);
            }
            dr.Close();
            con.Close();
            return li;
        }
        public void Inserir(string nome, string cidade, string endereco, string celular, string email, string data_nascimento)
        {
            string sql = "";
        }
    }
}
